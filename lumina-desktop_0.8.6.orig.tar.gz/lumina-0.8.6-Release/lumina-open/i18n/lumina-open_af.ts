<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>LFileDialog</name>
    <message>
        <source>Binary Location</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Find</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Set this application as the default </source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Audio</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Video</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Multimedia</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Development</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Education</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Game</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Graphics</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Network</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Office</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Science</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>System</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Utilities</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Other</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Find Application Binary</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Open With...</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Preferred</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Available</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Custom</source>
        <translation type="unfinished">
            </translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Application Error</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>The following application experienced an error and needed to close:</source>
        <translation type="unfinished">
            </translation>
    </message>
</context>
</TS>
