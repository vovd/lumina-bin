<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>LFileDialog</name>
    <message>
        <source>Binary Location</source>
        <translation>Ort der ausführbar Anwendungsdatei</translation>
    </message>
    <message>
        <source>Find</source>
        <translation>Finde</translation>
    </message>
    <message>
        <source>Set this application as the default </source>
        <translation>Diese Anwendung als Standard einstellen </translation>
    </message>
    <message>
        <source>OK</source>
        <translation>Weiter</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbruch</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Audio</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <source>Multimedia</source>
        <translation>Multimedia</translation>
    </message>
    <message>
        <source>Development</source>
        <translation>Entwicklung</translation>
    </message>
    <message>
        <source>Education</source>
        <translation>Bildung</translation>
    </message>
    <message>
        <source>Game</source>
        <translation>Spiel</translation>
    </message>
    <message>
        <source>Graphics</source>
        <translation>Grafisch</translation>
    </message>
    <message>
        <source>Network</source>
        <translation>Netzwerk</translation>
    </message>
    <message>
        <source>Office</source>
        <translation>Büro</translation>
    </message>
    <message>
        <source>Science</source>
        <translation>Wissenschaft</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Einstellungen</translation>
    </message>
    <message>
        <source>System</source>
        <translation>System</translation>
    </message>
    <message>
        <source>Utilities</source>
        <translation>Dienstprogramme</translation>
    </message>
    <message>
        <source>Other</source>
        <translation>Andere</translation>
    </message>
    <message>
        <source>Find Application Binary</source>
        <translation>Finde ausführbare Anwendungsdatei</translation>
    </message>
    <message>
        <source>Open With...</source>
        <translation>Öffnen mit ...</translation>
    </message>
    <message>
        <source>Preferred</source>
        <translation>Bevorzugte</translation>
    </message>
    <message>
        <source>Available</source>
        <translation>Verfügbar</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>Angepasst</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Application Error</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>The following application experienced an error and needed to close:</source>
        <translation type="unfinished">
            </translation>
    </message>
</context>
</TS>
