<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>LFileDialog</name>
    <message>
        <source>Binary Location</source>
        <translation>Binary Location</translation>
    </message>
    <message>
        <source>Find</source>
        <translation>Find</translation>
    </message>
    <message>
        <source>Set this application as the default </source>
        <translation>Set this application as the default </translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancel</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Audio</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <source>Multimedia</source>
        <translation>Multimedia</translation>
    </message>
    <message>
        <source>Development</source>
        <translation>Development</translation>
    </message>
    <message>
        <source>Education</source>
        <translation>Education</translation>
    </message>
    <message>
        <source>Game</source>
        <translation>Game</translation>
    </message>
    <message>
        <source>Graphics</source>
        <translation>Graphics</translation>
    </message>
    <message>
        <source>Network</source>
        <translation>Network</translation>
    </message>
    <message>
        <source>Office</source>
        <translation>Office</translation>
    </message>
    <message>
        <source>Science</source>
        <translation>Science</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Settings</translation>
    </message>
    <message>
        <source>System</source>
        <translation>System</translation>
    </message>
    <message>
        <source>Utilities</source>
        <translation>Utilities</translation>
    </message>
    <message>
        <source>Other</source>
        <translation>Other</translation>
    </message>
    <message>
        <source>Find Application Binary</source>
        <translation>Find Application Binary</translation>
    </message>
    <message>
        <source>Open With...</source>
        <translation>Open With...</translation>
    </message>
    <message>
        <source>Preferred</source>
        <translation>Preferred</translation>
    </message>
    <message>
        <source>Available</source>
        <translation>Available</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>Custom</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Application Error</source>
        <translation>Application Error</translation>
    </message>
    <message>
        <source>The following application experienced an error and needed to close:</source>
        <translation>The following application experienced an error and needed to close:</translation>
    </message>
</context>
</TS>
