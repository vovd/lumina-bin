<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>LFileDialog</name>
    <message>
        <source>Binary Location</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Find</source>
        <translation>Найти</translation>
    </message>
    <message>
        <source>Set this application as the default </source>
        <translation>Использовать это приложение по умолчанию </translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Звук</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Видео</translation>
    </message>
    <message>
        <source>Multimedia</source>
        <translation>Мультимедиа</translation>
    </message>
    <message>
        <source>Development</source>
        <translation>Разработка</translation>
    </message>
    <message>
        <source>Education</source>
        <translation>Образование</translation>
    </message>
    <message>
        <source>Game</source>
        <translation>Игры</translation>
    </message>
    <message>
        <source>Graphics</source>
        <translation>Графика</translation>
    </message>
    <message>
        <source>Network</source>
        <translation>Сети</translation>
    </message>
    <message>
        <source>Office</source>
        <translation>Офис</translation>
    </message>
    <message>
        <source>Science</source>
        <translation>Наука</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Настройки</translation>
    </message>
    <message>
        <source>System</source>
        <translation>Система</translation>
    </message>
    <message>
        <source>Utilities</source>
        <translation>Инструменты</translation>
    </message>
    <message>
        <source>Other</source>
        <translation>Разное</translation>
    </message>
    <message>
        <source>Find Application Binary</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Open With...</source>
        <translation>Открыть с помощью...</translation>
    </message>
    <message>
        <source>Preferred</source>
        <translation>Предпочтительный</translation>
    </message>
    <message>
        <source>Available</source>
        <translation>Доступно</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>Пользовательские</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Application Error</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>The following application experienced an error and needed to close:</source>
        <translation type="unfinished">
            </translation>
    </message>
</context>
</TS>
