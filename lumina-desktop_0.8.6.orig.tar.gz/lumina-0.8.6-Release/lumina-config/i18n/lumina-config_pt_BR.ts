<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>KeyCatch</name>
    <message>
        <source>Key Press Detection</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Press the keys you wish to assign.</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Notes: 
Special keys can only be detected if the proper keyboard driver is in use.
Current keyboard bindings will also be ignored.</source>
        <translation type="unfinished">
            </translation>
    </message>
</context>
<context>
    <name>MainUI</name>
    <message>
        <source>Desktop Configuration</source>
        <translation type="unfinished">Configuração da área de trabalho</translation>
    </message>
    <message>
        <source>Screen Number:</source>
        <translation type="unfinished">Número da tela:</translation>
    </message>
    <message>
        <source>Panels</source>
        <translation>Painéis</translation>
    </message>
    <message>
        <source>Top</source>
        <translation type="unfinished">Superior</translation>
    </message>
    <message>
        <source>Bottom</source>
        <translation>Inferior</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation>Aparência</translation>
    </message>
    <message>
        <source>Plugins</source>
        <translation>Plugins</translation>
    </message>
    <message>
        <source>Find Background Image(s)</source>
        <translation type="unfinished">Encontrar imagem(s) de fundo</translation>
    </message>
    <message>
        <source>Location:</source>
        <translation>Localização:</translation>
    </message>
    <message>
        <source>Menu</source>
        <translation>Menu</translation>
    </message>
    <message>
        <source>Set Default Terminal Application</source>
        <translation type="unfinished">Definir o aplicativo padrão para Terminal</translation>
    </message>
    <message>
        <source>Application Binaries (*)</source>
        <translation>Binários de aplicativos (*)</translation>
    </message>
    <message>
        <source>Invalid Binary</source>
        <translation>Binário inválido</translation>
    </message>
    <message>
        <source>The selected file is not executable!</source>
        <translation>O arquivo selecionado não é executável!</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Select Panel Color</source>
        <translation type="unfinished">Selecionar cor do painel</translation>
    </message>
    <message>
        <source>Select Application</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>App Name:</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Single Background</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Rotate Background</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source> Minutes</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Every </source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Add the selected plugin to the desktop</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Plugin</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Panel #1</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Size:</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Color:</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Sample</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Panel #2</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Terminal Command:</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Action</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Keyboard Shortcut</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Clear Shortcut</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Change Shortcut</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Group/Extension</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Default Application</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Group</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Extension</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Clear</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Set App</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Startup Routine</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>bin</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>file</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>General Options</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Window System</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>New Window Placement</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Focus Policy</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Window Theme</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Number of Workspaces</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Save Changes</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Ctrl+S</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>toolBar</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Desktop</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Desktop Appearance</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Panel Configuration</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Session</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Session Options</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Defaults</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Default Applications</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Shortcuts</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Keyboard Shortcuts</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Desktop Menu</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Left</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Right</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Click To Focus</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Active Mouse Focus</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Strict Mouse Focus</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Align in a Row</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Align in a Column</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Cascade</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Underneath Mouse</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>New Panel Plugin</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Add Plugin:</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Save Changes?</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>You currently have unsaved changes for this screen. Do you want to save them first?</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>System Default</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>No Background</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>(use system default)</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>File does not exist</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>New Menu Plugin</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Plugin:</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>New Application Group</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Name:</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>New File Extension</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Extension:</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Select Binary</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Select File</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>All Files (*)</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Add Desktop Plugins</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Note: Current key bindings need to be cleared and saved before they can be re-used.</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Enable numlock on startup</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Play chimes on startup</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Play chimes on exit</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Screen Resolution:</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Audio Volume Up</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Audio Volume Down</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Screen Brightness Up</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Screen Brightness Down</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Take Screenshot</source>
        <translation type="unfinished">
            </translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>User Button</source>
        <translation type="unfinished">Botão de usuário</translation>
    </message>
    <message>
        <source>This is the main system access button for the user (applications, directories, settings, log out).</source>
        <translation type="unfinished">Este é o botão principal de acesso ao sistema para o usuário (aplicativos, diretórios, configurações, sair).</translation>
    </message>
    <message>
        <source>Desktop Bar</source>
        <translation type="unfinished">Barra da área de trabalho</translation>
    </message>
    <message>
        <source>This provides shortcuts to everything in the desktop folder - allowing easy access to all your favorite files/applications.</source>
        <translation type="unfinished">Isto fornece atalhos para tudo na pasta da área de trabalho - permitindo acesso fácil para todos os seus arquivos/aplicativos favoritos.</translation>
    </message>
    <message>
        <source>Spacer</source>
        <translation>Espaçador</translation>
    </message>
    <message>
        <source>Invisible spacer to separate plugins.</source>
        <translation>Espaçador invisível para separar plugins.</translation>
    </message>
    <message>
        <source>Desktop Switcher</source>
        <translation type="unfinished">Alternador de áreas de trabalho</translation>
    </message>
    <message>
        <source>Controls for switching between the various virtual desktops.</source>
        <translation>Controles para alternar entre várias áreas de trabalho virtuais.</translation>
    </message>
    <message>
        <source>Battery Monitor</source>
        <translation>Monitor de bateria</translation>
    </message>
    <message>
        <source>Keep track of your battery status.</source>
        <translation type="unfinished">Acompanhe o estado da sua bateria.</translation>
    </message>
    <message>
        <source>Time/Date</source>
        <translation>Hora/Data</translation>
    </message>
    <message>
        <source>View the current time and date.</source>
        <translation>Visualize a hora e a data atual</translation>
    </message>
    <message>
        <source>Terminal</source>
        <translation>Terminal</translation>
    </message>
    <message>
        <source>Start the default system terminal.</source>
        <translation type="unfinished">Inicia o terminal padrão do sistema.</translation>
    </message>
    <message>
        <source>Applications</source>
        <translation>Aplicativos</translation>
    </message>
    <message>
        <source>Show the system applications menu.</source>
        <translation type="unfinished">Mostra o menu de aplicativos do sistema.</translation>
    </message>
    <message>
        <source>Separator</source>
        <translation>Separador</translation>
    </message>
    <message>
        <source>Static horizontal line.</source>
        <translation>Linha horizontal estática.</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Configurações</translation>
    </message>
    <message>
        <source>Show the desktop settings menu.</source>
        <translation type="unfinished">Mostra o menu de configurações da área de trabalho.</translation>
    </message>
    <message>
        <source>Task Manager</source>
        <translation>Gerenciador de tarefas</translation>
    </message>
    <message>
        <source>View and control any running application windows</source>
        <translation type="unfinished">Visualiza e controla todas as janelas de aplicativos em execução</translation>
    </message>
    <message>
        <source>System Tray</source>
        <translation>Bandeja do sistema</translation>
    </message>
    <message>
        <source>Display area for dockable system applications</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>File Manager</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Browse the system with the default file manager.</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Custom App</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Start a custom application</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>System Dashboard</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>View or change system settings (audio volume, screen brightness, battery life, virtual desktops).</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Calendar</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Display a calendar on the desktop</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Application Launcher</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Desktop button for launching an application</source>
        <translation type="unfinished">
            </translation>
    </message>
</context>
</TS>
