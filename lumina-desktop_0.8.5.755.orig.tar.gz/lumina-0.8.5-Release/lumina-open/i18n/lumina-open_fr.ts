<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>LFileDialog</name>
    <message>
        <source>Binary Location</source>
        <translation>Binaire Localisation</translation>
    </message>
    <message>
        <source>Find</source>
        <translation>Trouvé</translation>
    </message>
    <message>
        <source>Set this application as the default </source>
        <translation>Réglez cette application par défaut</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Audio</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Vidéo</translation>
    </message>
    <message>
        <source>Multimedia</source>
        <translation>Multimédia</translation>
    </message>
    <message>
        <source>Development</source>
        <translation>Développement</translation>
    </message>
    <message>
        <source>Education</source>
        <translation>Éducation</translation>
    </message>
    <message>
        <source>Game</source>
        <translation>Jeu</translation>
    </message>
    <message>
        <source>Graphics</source>
        <translation>Graphique</translation>
    </message>
    <message>
        <source>Network</source>
        <translation>Internet</translation>
    </message>
    <message>
        <source>Office</source>
        <translation>Bureautique</translation>
    </message>
    <message>
        <source>Science</source>
        <translation>Science</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Paramètres</translation>
    </message>
    <message>
        <source>System</source>
        <translation>Système</translation>
    </message>
    <message>
        <source>Utilities</source>
        <translation>Utilitaires</translation>
    </message>
    <message>
        <source>Other</source>
        <translation>Autres</translation>
    </message>
    <message>
        <source>Find Application Binary</source>
        <translation>Trouver une application binaire</translation>
    </message>
    <message>
        <source>Open With...</source>
        <translation>Ouvrir avec...</translation>
    </message>
    <message>
        <source>Preferred</source>
        <translation>Préférence</translation>
    </message>
    <message>
        <source>Available</source>
        <translation>Disponible</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>Personnaliser</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Application Error</source>
        <translation>Erreur d&apos;application</translation>
    </message>
    <message>
        <source>The following application experienced an error and needed to close:</source>
        <translation>L&apos;application suivante a rencontré une erreur et a dû se fermer:</translation>
    </message>
</context>
</TS>
