<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>LFileDialog</name>
    <message>
        <source>Binary Location</source>
        <translation>Binary Местоположение</translation>
    </message>
    <message>
        <source>Find</source>
        <translation>Намери</translation>
    </message>
    <message>
        <source>Set this application as the default </source>
        <translation>Задай това приложение по подразбиране</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>ОК</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отказ</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Аудио</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Видео</translation>
    </message>
    <message>
        <source>Multimedia</source>
        <translation>Мултимедия</translation>
    </message>
    <message>
        <source>Development</source>
        <translation>Разработка</translation>
    </message>
    <message>
        <source>Education</source>
        <translation>Обучение</translation>
    </message>
    <message>
        <source>Game</source>
        <translation>Игра</translation>
    </message>
    <message>
        <source>Graphics</source>
        <translation>Графика</translation>
    </message>
    <message>
        <source>Network</source>
        <translation>Мрежа</translation>
    </message>
    <message>
        <source>Office</source>
        <translation>Офис</translation>
    </message>
    <message>
        <source>Science</source>
        <translation>Наука</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Настройки</translation>
    </message>
    <message>
        <source>System</source>
        <translation>Системни</translation>
    </message>
    <message>
        <source>Utilities</source>
        <translation>Инструменти</translation>
    </message>
    <message>
        <source>Other</source>
        <translation>Други</translation>
    </message>
    <message>
        <source>Find Application Binary</source>
        <translation>Намери изпълнимият файл</translation>
    </message>
    <message>
        <source>Open With...</source>
        <translation>Отвори с...</translation>
    </message>
    <message>
        <source>Preferred</source>
        <translation>Предпочитан</translation>
    </message>
    <message>
        <source>Available</source>
        <translation>Наличен</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>По поръчка</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Application Error</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>The following application experienced an error and needed to close:</source>
        <translation type="unfinished">
            </translation>
    </message>
</context>
</TS>
