<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>LFileDialog</name>
    <message>
        <source>Binary Location</source>
        <translation>Localização do binário</translation>
    </message>
    <message>
        <source>Find</source>
        <translation>Encontrar</translation>
    </message>
    <message>
        <source>Set this application as the default </source>
        <translation>Definir este aplicativo como padrão </translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Áudio</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Vídeo</translation>
    </message>
    <message>
        <source>Multimedia</source>
        <translation>Multimídia</translation>
    </message>
    <message>
        <source>Development</source>
        <translation>Desenvolvimento</translation>
    </message>
    <message>
        <source>Education</source>
        <translation>Educação</translation>
    </message>
    <message>
        <source>Game</source>
        <translation>Jogos</translation>
    </message>
    <message>
        <source>Graphics</source>
        <translation>Gráficos</translation>
    </message>
    <message>
        <source>Network</source>
        <translation>Rede</translation>
    </message>
    <message>
        <source>Office</source>
        <translation>Escritório</translation>
    </message>
    <message>
        <source>Science</source>
        <translation>Ciência</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="unfinished">Configurações</translation>
    </message>
    <message>
        <source>System</source>
        <translation>Sistema</translation>
    </message>
    <message>
        <source>Utilities</source>
        <translation>Utilitários</translation>
    </message>
    <message>
        <source>Other</source>
        <translation>Outros</translation>
    </message>
    <message>
        <source>Find Application Binary</source>
        <translation type="unfinished">Encontrar binário do aplicativo</translation>
    </message>
    <message>
        <source>Open With...</source>
        <translation>Abrir com...</translation>
    </message>
    <message>
        <source>Preferred</source>
        <translation>Preferido</translation>
    </message>
    <message>
        <source>Available</source>
        <translation>Disponível</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>Personalizado</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Application Error</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>The following application experienced an error and needed to close:</source>
        <translation type="unfinished">
            </translation>
    </message>
</context>
</TS>
