<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="hu_HU">
<context>
    <name>LFileDialog</name>
    <message>
        <source>Binary Location</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Find</source>
        <translation>Keresés</translation>
    </message>
    <message>
        <source>Set this application as the default </source>
        <translation>Alkalmazás beállítása alapértelmezettnek</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Mégsem</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Audió</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Videó</translation>
    </message>
    <message>
        <source>Multimedia</source>
        <translation>Multimédia</translation>
    </message>
    <message>
        <source>Development</source>
        <translation>Fejlesztés</translation>
    </message>
    <message>
        <source>Education</source>
        <translation>Oktatás</translation>
    </message>
    <message>
        <source>Game</source>
        <translation>Játék</translation>
    </message>
    <message>
        <source>Graphics</source>
        <translation>Grafika</translation>
    </message>
    <message>
        <source>Network</source>
        <translation>Hálózat</translation>
    </message>
    <message>
        <source>Office</source>
        <translation>Iroda</translation>
    </message>
    <message>
        <source>Science</source>
        <translation>Tudomány</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Beállítások</translation>
    </message>
    <message>
        <source>System</source>
        <translation>Rendszer</translation>
    </message>
    <message>
        <source>Utilities</source>
        <translation>Segédeszközök</translation>
    </message>
    <message>
        <source>Other</source>
        <translation>Egyéb</translation>
    </message>
    <message>
        <source>Find Application Binary</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Open With...</source>
        <translation>Megnyitás ezzel...</translation>
    </message>
    <message>
        <source>Preferred</source>
        <translation type="unfinished">
            </translation>
    </message>
    <message>
        <source>Available</source>
        <translation>Elérhető</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>Egyéni</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Application Error</source>
        <translation>Alkalmazás hiba</translation>
    </message>
    <message>
        <source>The following application experienced an error and needed to close:</source>
        <translation>Az alkalmazás hibát észlelt, és bezárandó:</translation>
    </message>
</context>
</TS>
