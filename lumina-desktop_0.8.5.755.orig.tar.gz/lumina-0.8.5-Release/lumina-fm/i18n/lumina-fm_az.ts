<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="az_AZ">
<context>
    <name>MainUI</name>
    <message>
        <location filename="../MainUI.ui" line="14"/>
        <source>Insight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MainUI.ui" line="51"/>
        <source>Open Multimedia Player</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MainUI.ui" line="54"/>
        <location filename="../MainUI.ui" line="67"/>
        <location filename="../MainUI.ui" line="80"/>
        <location filename="../MainUI.ui" line="136"/>
        <location filename="../MainUI.ui" line="143"/>
        <location filename="../MainUI.ui" line="215"/>
        <location filename="../MainUI.ui" line="225"/>
        <location filename="../MainUI.ui" line="271"/>
        <location filename="../MainUI.ui" line="281"/>
        <location filename="../MainUI.ui" line="309"/>
        <location filename="../MainUI.ui" line="337"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MainUI.ui" line="64"/>
        <source>View Slideshow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MainUI.ui" line="77"/>
        <source>Restore File(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MainUI.ui" line="106"/>
        <source>Playlist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MainUI.ui" line="116"/>
        <location filename="../MainUI.ui" line="268"/>
        <source>Go to Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MainUI.ui" line="127"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MainUI.ui" line="212"/>
        <source>Go to Beginning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MainUI.ui" line="222"/>
        <source>Go to Previous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MainUI.ui" line="278"/>
        <source>Go to End</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MainUI.ui" line="356"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MainUI.ui" line="361"/>
        <source>Date Modified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MainUI.ui" line="366"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MainUI.ui" line="371"/>
        <source>Owner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MainUI.ui" line="381"/>
        <source>Restore entire directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MainUI.ui" line="384"/>
        <source>Restore All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MainUI.ui" line="394"/>
        <source>Restore Selected Item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MainUI.ui" line="397"/>
        <source>Restore Selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MainUI.ui" line="420"/>
        <source>Overwrite Existing Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MainUI.ui" line="443"/>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MainUI.ui" line="451"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MainUI.ui" line="457"/>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MainUI.ui" line="465"/>
        <source>Bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MainUI.ui" line="476"/>
        <source>toolBar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MainUI.ui" line="497"/>
        <source>New &amp;Tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MainUI.ui" line="502"/>
        <source>Close Tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MainUI.ui" line="507"/>
        <source>E&amp;xit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MainUI.ui" line="512"/>
        <source>&amp;Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MainUI.ui" line="523"/>
        <source>Shortcuts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MainUI.ui" line="534"/>
        <source>Music Player</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MainUI.ui" line="545"/>
        <source>Image Viewer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MainUI.ui" line="550"/>
        <source>UpDir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MainUI.ui" line="553"/>
        <source>Go up one directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MainUI.ui" line="558"/>
        <source>Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MainUI.ui" line="561"/>
        <source>Go to your home directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MainUI.ui" line="572"/>
        <source>View Hidden Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MainUI.ui" line="577"/>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MainUI.ui" line="580"/>
        <source>Back to directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MainUI.ui" line="585"/>
        <source>Refresh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MainUI.ui" line="588"/>
        <source>Refresh Directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MainUI.ui" line="591"/>
        <source>F5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MainUI.ui" line="596"/>
        <source>Bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MainUI.ui" line="599"/>
        <source>Bookmark this directory</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
