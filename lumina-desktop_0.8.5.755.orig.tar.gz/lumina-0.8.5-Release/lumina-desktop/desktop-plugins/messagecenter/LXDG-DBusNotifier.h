//===========================================
//  Lumina-DE source code
//  Copyright (c) 2015, Ken Moore
//  Available under the 3-clause BSD license
//  See the LICENSE file for full details
//===========================================
//  Simple DBUS message handler for the FreeDesktop desktop notifications specification


class LXDG-DBusNotifier : public QDBusVirtualObkect{
	Q_OBJECT
public:
	
private:
	

};
